# AVNI AI — phone se APK banane ki guide

Ye Android source project hai; ZIP khud installable APK nahi hai. Is repo mein GitHub Actions workflow add hai jo source GitHub par upload/push hone ke baad APK build kar sakta hai.

## GitHub phone workflow
1. Chrome mein github.com par sign in karo.
2. `+` → `New repository` banao; naam `avni-ai`, Public ya Private, phir Create repository.
3. Repository mein `Add file` → `Upload files` se ZIP ko as-is upload karne se source build nahi hoga. ZIP ko phone ke file manager/archive app se extract karo, phir extracted `AVNI_Android_Starter` folder ke **andar ki saari files aur folders** repository root mein upload karo. Hidden `.github` folder ko bhi upload karna zaroori hai; agar mobile website hidden folder upload nahi karne de, GitHub Codespaces/desktop-mode ya kisi ZIP-upload/import method ki zaroorat padegi.
4. Upload/commit ke baad repository → Actions tab kholo. `Build AVNI APK` workflow run hona chahiye. Agar `workflow_dispatch` list ho, use kholo aur `Run workflow` dabao.
5. Green successful run khol → `Artifacts` → `AVNI-debug-APK` download karo. ZIP artifact ko extract karo; andar `app-debug.apk` hoga.
6. APK install karte waqt Android unknown-app install permission pooch sakta hai. Sirf apne khud ke build par install permission allow karo.

## Current functionality / limits
- Hindi speech recognition Android ke speech recognizer par depend karta hai; mic permission aur internet/model availability zaroori ho sakti hai.
- Text-to-speech Android ke installed Hindi voice par depend karta hai.
- Basic commands apps kholte hain; SMS sirf composer kholta hai taaki user review karke khud bheje.
- Notification reading ke liye Notification Access explicitly enable karna hoga.
- Ye abhi full cloud-AI assistant nahi hai; contacts ko auto-call, WhatsApp auto-send/reply, always-on wake word, ya har app ka full control implement nahi hai.
- Debug APK signed release/distribution build nahi hai. Install karne se pehle permissions aur behavior review karo.
