package com.avni.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView status, transcript, latestMessage;
    private TextToSpeech tts;
    private String pendingRecipient = "";
    private String pendingBody = "";
    private static final int REQ_SPEECH = 100;
    private static final int REQ_AUDIO = 101;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        buildUi();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("hi", "IN"));
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.US);
                }
            }
        });
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 30, 28, 24);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFF05070C);
        scroll.addView(root);

        TextView butterfly = label("🦋");
        butterfly.setTextSize(58);
        butterfly.setGravity(Gravity.CENTER);
        root.addView(butterfly, matchWrap());

        TextView title = label("A V N I");
        title.setTextSize(34);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.25f);
        root.addView(title, matchWrap());

        TextView subtitle = label("YOUR PERSONAL AI ASSISTANT\\nLISTEN  /  THINK  /  ACT");
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setTextSize(13);
        subtitle.setTextColor(0xFF9CB7D8);
        subtitle.setPadding(0, 4, 0, 22);
        root.addView(subtitle, matchWrap());

        status = label("AVNI READY • Tap and speak");
        status.setGravity(Gravity.CENTER);
        root.addView(status, matchWrap());

        Button listen = button("◉  TAP TO TALK");
        listen.setTextSize(18);
        listen.setPadding(8, 16, 8, 16);
        listen.setOnClickListener(v -> listen());
        root.addView(listen, matchWidth(68));

        transcript = label("Try: “Avni, YouTube kholo”");
        root.addView(transcript, matchWrap());

        Button read = button("READ LATEST MESSAGE NOTIFICATION");
        read.setOnClickListener(v -> {
            String msg = AvniNotificationListener.latestText;
            latestMessage.setText("Latest notification: " + msg);
            speak(msg);
        });
        root.addView(read, matchWidth(56));

        Button notifications = button("ENABLE NOTIFICATION ACCESS");
        notifications.setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        root.addView(notifications, matchWidth(56));

        latestMessage = label("Latest notification: none captured yet");
        root.addView(latestMessage, matchWrap());

        Button sms = button("SEND A TEST SMS (OPENS COMPOSER)");
        sms.setOnClickListener(v -> {
            pendingRecipient = "";
            pendingBody = "Hi! Message sent with help from AVNI.";
            openSmsComposer(pendingRecipient, pendingBody);
        });
        root.addView(sms, matchWidth(56));

        TextView note = label("Starter prototype: voice commands, app launching, call/SMS composer shortcuts and notification reading. Sensitive actions open Android's own interface for your review.");
        note.setTextSize(12);
        note.setTextColor(0xFF9CB7D8);
        root.addView(note, matchWrap());

        setContentView(scroll);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }
    private LinearLayout.LayoutParams matchWidth(int height) {
        return new LinearLayout.LayoutParams(-1, height);
    }
    private TextView label(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(0xFFF0F5FF);
        t.setTextSize(15);
        t.setPadding(8, 14, 8, 14);
        return t;
    }
    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(0xFFFFFFFF);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF17243A));
        return b;
    }

    private void listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Bolo, AVNI sun rahi hai...");
        try {
            startActivityForResult(i, REQ_SPEECH);
        } catch (ActivityNotFoundException e) {
            status.setText("Speech recognition is not available on this phone.");
            speak("Is phone par speech recognition available nahi hai.");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) handleCommand(results.get(0));
        }
    }

    private void handleCommand(String raw) {
        String command = raw.toLowerCase(Locale.ROOT).trim();
        transcript.setText("You: " + raw);
        status.setText("AVNI is processing...");
        if (command.contains("youtube")) {
            openAppOrSearch("com.google.android.youtube", "YouTube");
        } else if (command.contains("instagram")) {
            openAppOrSearch("com.instagram.android", "Instagram");
        } else if (command.contains("camera")) {
            launchIntent(new Intent("android.media.action.IMAGE_CAPTURE"), "Camera");
        } else if (command.contains("setting")) {
            launchIntent(new Intent(Settings.ACTION_SETTINGS), "Settings");
        } else if (command.contains("message") || command.contains("msg") || command.contains("sms")) {
            String body = "Hi! Message prepared with AVNI.";
            openSmsComposer("", body);
        } else if (command.contains("call") || command.contains("phone")) {
            status.setText("Call action");
            speak("Call karne ke liye contact ya number dialer mein select karo.");
            launchIntent(new Intent(Intent.ACTION_DIAL), "Phone dialer");
        } else {
            status.setText("Command received");
            String response = "Maine suna: " + raw + ". Is starter version mein is command ka AI action abhi connect nahi hai.";
            speak(response);
        }
    }

    private void openAppOrSearch(String packageName, String appName) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
        if (launch != null) launchIntent(launch, appName);
        else {
            Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(appName)));
            launchIntent(web, appName + " search");
        }
    }

    private void launchIntent(Intent intent, String actionName) {
        try {
            startActivity(intent);
            status.setText("Opened: " + actionName);
            speak(actionName + " khol rahi hoon.");
        } catch (Exception e) {
            status.setText("Could not open: " + actionName);
            speak(actionName + " open nahi ho saka.");
        }
    }

    private void openSmsComposer(String recipient, String body) {
        Uri uri = recipient.isEmpty() ? Uri.parse("smsto:") : Uri.parse("smsto:" + Uri.encode(recipient));
        Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
        intent.putExtra("sms_body", body);
        try {
            startActivity(intent);
            status.setText("SMS composer opened — review before sending");
            speak("Message composer khol diya hai. Bhejne se pehle check kar lo.");
        } catch (Exception e) {
            status.setText("No SMS app found");
            speak("SMS app nahi mili.");
        }
    }

    private void speak(String text) {
        if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "avni-utterance");
    }

    @Override protected void onResume() {
        super.onResume();
        if (latestMessage != null) latestMessage.setText("Latest notification: " + AvniNotificationListener.latestText);
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
