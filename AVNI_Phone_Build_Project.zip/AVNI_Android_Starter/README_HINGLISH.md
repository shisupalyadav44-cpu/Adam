# AVNI AI — Android starter prototype

Ye ek **starter project** hai, final full JARVIS-style assistant nahi. Ismein:
- Dark AVNI-themed Android UI
- Tap-to-speak Hindi speech recognition
- Text-to-speech replies
- YouTube/Instagram/Camera/Settings open karne ke basic voice commands
- SMS composer open karna (user message review karke khud send kare)
- Optional Android notification-listener service, latest notification title/text ko prototype mein dikhane ke liye

## Build karne ke liye
1. ZIP extract karo.
2. Android Studio mein `AVNI_Android_Starter` folder open karo.
3. Gradle sync complete hone do.
4. Android SDK Platform 35 aur compatible JDK (Android Studio ka bundled JDK) install/available rakho.
5. Run button se apne Android phone par install karo, ya Build > Build APK(s) use karo.

## Phone par setup
- Microphone permission allow karo.
- Notification announcements test karne ke liye app mein `ENABLE NOTIFICATION ACCESS` dabao aur Android Settings mein AVNI ko enable karo.
- Notification access sensitive permission hai; sirf tab enable karo jab tum is prototype par bharosa karte ho.

## Voice commands currently implemented
- “YouTube kholo”
- “Instagram kholo”
- “Camera kholo”
- “Settings kholo”
- “Message bhejo” / “SMS” (SMS composer opens; sample text is a placeholder)
- “Call karo” (dialer opens)

## Important limitations
- Ye build AI backend se connected nahi hai; general questions ka intelligent answer abhi implement nahi hai.
- Ye prototype arbitrary contact ko identify karke automatically message nahi bhejta.
- WhatsApp ke liye direct send/reply integration included nahi hai; supported notification actions app-specific hote hain.
- Notification listener sirf notifications ka available title/text capture karta hai; kuch apps message content hide kar sakte hain.
- Incoming call auto-answer, wake-word always-on listening, unrestricted phone control, and background operation require additional Android roles/permissions, app-specific support, and substantial testing.
- SMS composer user ko final review deta hai; app silently send nahi karti.
- Never put AI API keys in a public Android app. Add a secure backend for AI integration.

## Next development steps
1. Add contact picker and safe recipient resolution.
2. Add a secure backend for an AI model.
3. Add explicit confirmation flow for recipient + message body.
4. Improve notification privacy and supported reply actions.
5. Test on the target Android version/device.

## Phone se cloud APK build
Project mein `.github/workflows/build-apk.yml` add kiya hai. Phone se repository root mein source files upload/commit karne par GitHub Actions debug APK build karke `AVNI-debug-APK` artifact deta hai. Detailed steps aur current limitations ke liye `PHONE_BUILD_GUIDE_HINGLISH.md` dekho. ZIP source project hai, APK nahi.
